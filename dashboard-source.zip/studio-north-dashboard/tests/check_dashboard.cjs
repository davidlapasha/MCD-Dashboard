const fs=require('fs'),vm=require('vm'),assert=require('assert');
const path=require('path');const base=path.resolve(__dirname,'..');const file=path.join(base,'dashboard.html'),h=fs.readFileSync(file,'utf8');
const data=JSON.parse(h.match(/<script id="data" type="application\/json">([\s\S]*?)<\/script>/)[1]);
const js=h.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
const ids={};const el=id=>ids[id]??=( {id,value:id==='measure'?'retention':'',clientWidth:900,innerHTML:'',textContent:'',children:[],classList:{toggle(){}},add(o){this.children.push(o)},replaceChildren(...x){this.children=x},setAttribute(k,v){this[k]=v}} );
let tick;const tabs=['cohorts','retention','acquisition'].map(x=>({...el('tab-'+x),dataset:{tab:x}}));
const ctx=vm.createContext({console,Intl,Math,Number,JSON,Array,Option:function(text,value){this.text=text;this.value=value},document:{getElementById:id=>id==='data'?{textContent:JSON.stringify(data)}:el(id),querySelectorAll:()=>tabs},window:{addEventListener(){}},setInterval:fn=>{tick=fn;return 1},clearInterval:()=>{tick=null}});
vm.runInContext(js,ctx);
assert.equal(el("month").value,23);assert(el("trajectory").innerHTML.includes('class="prediction"'));
assert(!h.includes('<tbody id="values">'));assert(el("ltv-graph").innerHTML.includes('class="prediction"'));
for(let i=0;i<24;i++){
 vm.runInContext(`move(${i})`,ctx);
 assert.equal(el('month').value,i);assert(el('ltv-graph').innerHTML.includes(data.snapshots[i].month));
 assert.equal((el('cohort-options').innerHTML.match(/type="checkbox"/g)||[]).length,i+1);
 assert(data.snapshots[i].cells.every(x=>{const d=new Date(x.cohort_month+'T00:00:00Z');d.setUTCMonth(d.getUTCMonth()+x.age_month);return d.toISOString().slice(0,10)<data.snapshots[i].cutoff}));
 assert(data.snapshots[i].tests.every(x=>x.followup_end_at.slice(0,10)<=data.snapshots[i].cutoff));
 if(i<23){assert(!el('ltv-graph').innerHTML.includes('class="prediction"'));assert(el('decision-table').innerHTML==='');}
}
vm.runInContext("selected=['2025-07'];draw()",ctx);assert(el('trajectory').innerHTML.includes('class="prediction"'));
el('measure').value='revenue';el('measure').onchange();assert(el('trajectory').innerHTML.includes('Monthly')===false);assert(el('chart-summary').textContent.includes('6 forecast'));
el('month').value='0';el('month').onchange();assert(!el('trajectory').innerHTML.includes('class="prediction"'));assert.equal((el('cohort-options').innerHTML.match(/type="checkbox"/g)||[]).length,1);
el('next').onclick();assert.equal(el('month').value,1);el('prev').onclick();assert.equal(el('month').value,0);
el('play').onclick();assert(tick);tick();assert.equal(el('month').value,1);el('play').onclick();assert.equal(tick,null);
el("show-forecast").onclick();assert.equal(el("month").value,23);assert(el("trajectory").innerHTML.includes('class="prediction"'));
el('cohort-options').onchange({target:{type:'checkbox',checked:true,value:'2025-06'}});assert(el('trajectory').innerHTML.includes('2025-06'));assert.equal((el('trajectory').innerHTML.match(/<g style=/g)||[]).length,3);
el('cohort-options').onchange({target:{type:'checkbox',checked:false,value:'2025-06'}});assert.equal((el('trajectory').innerHTML.match(/<g style=/g)||[]).length,2);
vm.runInContext("selected=[];draw()",ctx);assert(el('trajectory').innerHTML.includes('Select at least one joining cohort'));
for(const t of tabs)t.onclick();
vm.runInContext('move(0)',ctx);assert(el('ltv-graph').innerHTML.includes('No full 12-receipt value observed yet'));assert(el('payback-graph').innerHTML.includes('No acquisition-cost recovery observed yet'));
for(const snap of data.snapshots)for(const c of snap.cohorts){assert(c.cac<160);if(c.ltv!==null)assert(c.ltv<400);if(c.payback!==null)assert(c.payback<=12);}for(const c of data.finalForecasts){assert(c.ltv_before_cac_mean<400);if(c.payback_month!==null)assert(c.payback_month<=12);}
const result={javascript_syntax:'passed',month_states_checked:24,controls:'passed: previous, next, select, play/pause, tabs, measure change, multi-cohort checkboxes and Show observed + forecast',forecast_visibility:'passed: hidden before latest month',future_records:'passed: no later cohorts or operating months; tests gated by completion',browser_rendering:'not verified: macOS sandbox prevented Chromium launch'};
fs.writeFileSync(path.join(base,'ui-checks.json'),JSON.stringify(result,null,2));console.log(result);
